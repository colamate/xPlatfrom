import React from 'react';

const Home: React.FC = () => {
  return (
    <div>
      <h1>Home Page</h1>
      <p>This is the Home page.</p>
    </div>
  );
};

export default Home;