import React from 'react';

const Demo: React.FC = () => {
  return (
    <div>
      <h1>Demo Page</h1>
      <p>This is the demo page.</p>
    </div>
  );
};

export default Demo;