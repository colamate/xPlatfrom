declare module '@pages/*' {
    import React from 'react'
    const component: React.ComponentType
    export default component
}